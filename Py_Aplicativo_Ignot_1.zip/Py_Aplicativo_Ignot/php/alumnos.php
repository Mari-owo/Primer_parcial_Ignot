
    <?php
    $boton = $_POST['btn'];
    if($boton == "registrarse"){
    $nombre= $_POST['nombre'];
    $apellidop= $_POST['apellidoP'];
    $apellidom= $_POST['apellidoM'];
    $correoP= $_POST['correoP'];
    $licenciatura= $_POST['licenciatura'];
    $curp= $_POST['curp'];
    $celular= $_POST['celular'];
    }
    if($boton == "entrar"){
        $email=$_POST['correo'];
        $contraseña= $_POST['contraseña'];   
    };
    $usuario = "root";
    $pasword = "";
    $servidor = "localhost";
    $basededatos = "login_alumnos";
    //crea una conexion en la base de datos de mysql conect()
    $conexion = mysqli_connect($servidor, $usuario, $pasword)or 
    die ("no se ha podido conectar al servidor en base de datos");

    //seleccion de la base de datos a utilizar
    $db = mysqli_select_db($conexion, $basededatos) or 
    die ("pues va a ser que no se a podido conectar con la base de datos");

    if ($boton == "registrarse"){
            $query = "INSERT INTO registros (nombre, apellidoP, apellidoM, correoP, licenciatura, curp, celular ) VALUES ('$nombre', '$apellidop', '$apellidom', '$correoP', '$licenciatura', '$curp', '$celular');";
            $result = mysqli_query($conexion, $query) or die ("ERROR Usuario existente");

            header("Location: index.html");
    }

    if($boton == "entrar"){
                $query = "SELECT * FROM login WHERE contraseña = '$contraseña' and correo = '$email';";
                $result = mysqli_query($conexion, $query) or die ('ERROR "registrate"');
                $band=true;
                while ($columna = mysqli_fetch_array($result)){
                   
                if($columna['correo'] == $email & $columna['contraseña'] == $contraseña){
                $band=true;
                        header("Location: admi.php");
                    }else{
                        echo "usuario inexistente";
                    }
            }
    }
    echo"Usario inexistente";
    mysqli_close($conexion);
    ?>s

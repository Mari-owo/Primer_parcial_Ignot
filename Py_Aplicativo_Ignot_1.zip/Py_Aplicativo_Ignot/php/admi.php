<!DOCTYPE >
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/style.css">
    <title>Index</title>
</head>
<body>
   <header>
    <nav class="navbar navbar-dark" style="background-color: rgb(105, 59, 148);">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img src="../img/icon/estrella.png" alt="" width="45" height="40" class="d-inline-block align-text-top">
            Administración
          </a>
          
          <nav class="navbar navbar-dark-color" style="background-color: rgb(105, 59, 148);">
            <div class="container-fluid">
                
                <!-- Example single danger button -->
               <h4><a href="../html/alumno.html">Salir</a></h4>
                </div>
          </nav>
        </div>
      </nav>
   </header>
   <main>
    <div class="container"> <hr>
      <h3 class="textod">Información de Alumnos</h3> 
        <hr> 
        <table class="table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Apellido Paterno</th>
                <th scope="col">Apellido Materno</th>
                <th scope="col">Correo</th>
                <th scope="col">Licenciatura</th>
                <th scope="col">CURP</th>
                <th scope="col">Celular</th>
                <th scope="col">Acción</th>
              </tr>
            </thead>
            <tbody>
                <?php
              
                $usuario = "root";
                $pasword = "";
                $servidor = "localhost";
                $basededatos = "login_alumnos";
                //crea una conexion en la base de datos de mysql conect()
                $conexion = mysqli_connect($servidor, $usuario, $pasword)or 
                die ("no se ha podido conectar al servidor en base de datos");
            
                //seleccion de la base de datos a utilizar
                $db = mysqli_select_db($conexion, $basededatos) or 
                die ("pues va a ser que no se a podido conectar con la base de datos");
            
                            $query = "SELECT * FROM registros";
                            $result = mysqli_query($conexion, $query);
                            $band=true;
                            while ($columna = mysqli_fetch_array($result)){
                              ?> 
                              <tr>
                              <td><?php echo $columna ['idregistros'] ?></td>
                              <td><?php echo $columna ['nombre'] ?></td>
                              <td><?php echo $columna ['apellidoP'] ?></td>
                              <td><?php echo $columna ['apellidoM'] ?></td>
                              <td><?php echo $columna ['correoP'] ?></td>
                              <td><?php echo $columna ['licenciatura'] ?></td>
                              <td><?php echo $columna ['curp'] ?></td>
                              <td><?php echo $columna ['celular'] ?></td>
                              <td>
                                   <a href="editar.php?id=<?php echo $columna['idregistros'] ?>" class="btn btn-primary">Editar</a>
                                  <a href="eliminar.php?id=<?php echo $columna ['idregistros'] ?>" class="btn btn-danger">Borrar</a>
                              </td>
                              </tr>


<?php
                            }
                            
                        
                
               
                mysqli_close($conexion);
                ?>
            </tbody>
          </table>
          
    </div>

   </main>
   <footer>
    <hr>
    
      <nav class="navbar navbar-dark" style="background-color: rgb(105, 59, 148);">
          <div class="container-fluid">
            <div class="container"> 
                <div class="row">
                  <div class="col-md-4"> 
                    <img src="../img/logoUNI2.png" alt="" width="250" height="250">
                </div>
                  <div class="col-md-4">  <br> <br> <br> <br>
            <a class="navbar-brand" href="#">
              <img src="../img/icon/facebook.png" alt="" width="40" height="40" class="d-inline-block align-text-top">
              Facebook
            </a>
            <a class="navbar-brand" href="#">
              <img src="../img/icon/instagram.png" alt="" width="40" height="40" class="d-inline-block align-text-top">
              Instragram
            </a>
            <a class="navbar-brand" href="#">
              <img src="../img/icon/twitter.png" alt="" width="40" height="40" class="d-inline-block align-text-top">
              Twitter
            </a>
            <a class="navbar-brand" href="#">
              <img src="../img/icon/tiktok.png" alt="" width="40" height="40" class="d-inline-block align-text-top">
              Tiktok
            </a>
          
                  </div>
          <!-- --> 
          <div class="col-md-4">  <br> <br> <br> <br>
            <h5 style="color: white;">Copyright 2023 © Universidad Saints Row.</h5> 
      
          </div>
      
      </div>
            <br>
            </div>
            </div>
          </div>

        </nav>
      
   </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>
<!DOCTYPE >
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/style.css">
    <title>Index</title>
</head>
<body>
   <header>
    <nav class="navbar navbar-dark" style="background-color: rgb(105, 59, 148);">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <img src="/img/icon/estrella.png" alt="" width="45" height="40" class="d-inline-block align-text-top">
            Editar Información
          </a>
          
          <nav class="navbar navbar-dark-color" style="background-color: rgb(105, 59, 148);">
            <div class="container-fluid">
                
                <!-- Example single danger button -->
                <a href="/index.html"><h4 class="texblanco">Salir</h4></a>
                </div>
          </nav>
        </div>
      </nav>
   </header>
   <main>
    <div class="container"> <hr>
      <h3 class="textod">Información de Alumnos</h3> 
        <hr> 
       
                <?php
              
                $usuario = "root";
                $pasword = "";
                $servidor = "localhost";
                $basededatos = "login_alumnos";
                //crea una conexion en la base de datos de mysql conect()
                $conexion = mysqli_connect($servidor, $usuario, $pasword)or 
                die ("no se ha podido conectar al servidor en base de datos");
            
                //seleccion de la base de datos a utilizar
                $db = mysqli_select_db($conexion, $basededatos) or 
                die ("pues va a ser que no se a podido conectar con la base de datos");


               if(isset($_POST['update'])){

                $id=$_POST['id']; 
                $nombre = $_POST['nombre'];
                $apellidop = $_POST['apellidoP'];
                $apellidom = $_POST['apellidoM'];
                $correo = $_POST['correoP'];
                $licenciatura = $_POST['licenciatura'];
                $curp = $_POST['curp'];
                $celular = $_POST['celular'];

                $query = "UPDATE registros set nombre = '$nombre', apellidoP = '$apellidop', apellidoM = '$apellidom', correoP = '$correo', licenciatura = '$licenciatura', curp = '$curp', celular = '$celular' WHERE idregistros= $id";
                           $resultado=mysqli_query($conexion, $query);
                            header("Location: admi.php");

               }else{

                 $id=$_GET['id']; 
                 $query = "SELECT * FROM registros where idregistros='".$id."'";
                 $result = mysqli_query($conexion, $query);
                 $columna = mysqli_fetch_assoc($result);
                               
                                $nombre = $columna['nombre'];
                                $apellidop = $columna['apellidoP'];
                                $apellidom = $columna['apellidoM'];
                                $correo = $columna['correoP'];
                                $licenciatura = $columna['licenciatura'];
                                $curp = $columna['curp'];
                                $celular = $columna['celular'];
 
                                mysqli_close($conexion);
                ?>
      <div class="row">
        <form action="<?=$_SERVER['PHP_SELF'] ?>" method="post">
        <input name="id" type="hidden" value="<?php echo $columna ['idregistros'] ?>" class="form-control"> <br>
          <label>Nombre:</label>
          <input name="nombre" type="text" value="<?php echo $columna ['nombre'] ?>" class="form-control"> <br>
          <label>Apellido paterno:</label>
          <input name="apellidoP" type="text" value="<?php echo $columna ['apellidoP'] ?>" class="form-control"> <br>
          <label>Apellido Materno:</label>
          <input name="apellidoM" type="text" value="<?php echo $columna ['apellidoM'] ?>" class="form-control"> <br>
          <label>Correo:</label>
          <input name="correoP" type="email" value="<?php echo $columna ['correoP'] ?>" class="form-control"> <br>
          <select name='licenciatura' class='form-select' aria-label='<?php echo $columna ['licenciatura'] ?>'>
          <option selected><?php echo $columna ['licenciatura'] ?></option>
          <option value='Programacion y Webmaster'>Programacion y Webmaster</option>
          <option value='Gatronomia'>Gatronomia</option>
          <option value='Derecho'>Derecho</option>
        </select>
        <label>Curp:</label> 
        <input name="curp" type="text" value="<?php echo $columna ['curp'] ?>" class="form-control"> <br>
        <label>Numero de telefono:</label>
        <input name="celular" type="number" value="<?php echo $columna ['celular'] ?>" class='form-control'> <br>
                              
       <input type="submit" class="btn btn-success" name="update" value="Modificar">




        </form>

        <?php 
        
        }
        ?>
      </div>
                       <!--  if(isset($_GET['id'])){ 
                            $id = $_GET['id'];
                        
                            $query = "SELECT * FROM registros WHERE idregistros = $id";
                            $result = mysqli_query($conexion, $query);
                            if (mysqli_num_rows($result) == 1) {
                                $columna = mysqli_fetch_array($result);
                               
                                $nombre = $columna['nombre'];
                                $apellidop = $columna['apellidoP'];
                                $apellidom = $columna['apellidoM'];
                                $correo = $columna['correoP'];
                                $licenciatura = $columna['licenciatura'];
                                $curp = $columna['curp'];
                                $celular = $columna['celular'];
                              
                            }
                           }
                              
                           if (isset($_POST['update'])) {
                            $id = $_GET['id'];
                            $nombre = $_POST['nombre'];
                            $apellidop = $_POST['apellidoP'];
                            $apellidom = $_POST['apellidoM'];
                            $correo = $_POST['correoP'];
                            $licenciatura = $_POST['licenciatura'];
                            $curp = $_POST['curp'];
                            $celular = $_POST['celular'];

                            $query = "UPDATE registros set nombre = '$nombre', apellidoP = '$apellidop', apellidoM = '$apellidom', correoP = '$correo', licenciatura = '$licenciatura', curp = '$curp', celular = '$celular' WHERE id = $id";
                            mysqli_query($conexion, $query);
                            header("Location: admi.php");
                          }

                          ?>
                
      <div class="row"
      <div class="col-md-12 mx-auto">
                       <div class="card card-body">
                       <form action="editar.php?id="
                        <input name="nombre" type="text" value='' class="form-control" placeholder="Actualiza tu nombre">  <br>
                          <input name="apellidoP" type="text" value="" class="form-control"placeholder="Actualiza tu primer apellido"> <br>
                          <input name="apellidoM" type="text" value="" class="form-control"placeholder="Actualiza tu segundo apellido"> <br>
                        <input name="correo" type="email" value='' class="form-control" placeholder="Actualiza tu correo electronico"> <br>
                        <div class='dropdown'>
                                       
                                       <select name='licenciatura' class='form-select' aria-label='Default select example'>
                                           <option selected>Seleccione su Licenciatura</option>
                                           <option value='Programacion y Webmaster'>Programacion y Webmaster</option>
                                           <option value='Gatronomia'>Gatronomia</option>
                                           <option value='Derecho'>Derecho</option>
                                         </select>
                                     </div> <br>
                              <input name='curp' type='text' value='' class='form-control' placeholder='Actualiza tu curp'> <br>
                              <input name='celular' type='number' value='' class='form-control' placeholder='Actualiza tu numero de celular'> <br>
                              
                              <button type='submit' class='btn btn-success' name='update'>Modificar</button>
                            </form>
                          </div>
            </div>
          </div>


    </div> -->

   </main>
   <footer>
    <hr>
    
      <nav class='navbar navbar-dark' style='background-color: rgb(105, 59, 148);'>
          <div class='container-fluid'>
            <div class='container'> 
                <div class='row'>
                  <div class='col-md-4'> 
                    <img src='img/logoUNI2.png' alt='' width='250' height='250'>
                </div>
                  <div class='col-md-4'>  <br> <br> <br> <br>
            <a class='navbar-brand' href='#'>
              <img src='/img/icon/facebook.png' alt='' width='40' height='40' class='d-inline-block align-text-top'>
              Facebook
            </a>
            <a class='navbar-brand' href='#'>
              <img src='/img/icon/instagram.png' alt='' width='40' height='40' class='d-inline-block align-text-top'>
              Instragram
            </a>
            <a class='navbar-brand' href='#'>
              <img src='/img/icon/twitter.png' alt='' width='40' height='40' class='d-inline-block align-text-top'>
              Twitter
            </a>
            <a class='navbar-brand' href='#'>
              <img src='/img/icon/tiktok.png' alt='' width='40' height='40' class='d-inline-block align-text-top'>
              Tiktok
            </a>
          
                  </div>
          <!-- --> 
          <div class='col-md-4'>  <br> <br> <br> <br>
            <h5 style='color: white;'>Copyright 2023 © Universidad Saints Row.</h5> 
      
          </div>
      
      </div>
            <br>
            </div>
            </div>
          </div>

        </nav>
      
   </footer>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
</body>
</html>

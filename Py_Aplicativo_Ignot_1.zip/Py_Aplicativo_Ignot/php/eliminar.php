<?php
              
                $usuario = "root";
                $pasword = "";
                $servidor = "localhost";
                $basededatos = "login_alumnos";
                //crea una conexion en la base de datos de mysql conect()
                $conexion = mysqli_connect($servidor, $usuario, $pasword)or 
                die ("no se ha podido conectar al servidor en base de datos");
            
                //seleccion de la base de datos a utilizar
                $db = mysqli_select_db($conexion, $basededatos) or 
                die ("pues va a ser que no se a podido conectar con la base de datos");
            

                            if(isset($_GET['id'])){ 
                                $id = $_GET['id'];
                            
                            $query = "DELETE FROM registros WHERE idregistros = $id";
                            $result = mysqli_query($conexion, $query);
                            if (!$result) {
                                die("Query Failed");
                            }

                            header("Location: admi.php");
                            }
                        
                
               
                mysqli_close($conexion);
                ?>